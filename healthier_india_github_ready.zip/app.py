from flask import Flask, jsonify, render_template, request
import sqlite3
from pathlib import Path

BASE = Path(__file__).parent
DB = BASE / "healthcare.db"
app = Flask(__name__)

def init_db():
    con = sqlite3.connect(DB)
    con.execute("""CREATE TABLE IF NOT EXISTS health_resources (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        audience TEXT NOT NULL
    )""")
    count = con.execute("SELECT COUNT(*) FROM health_resources").fetchone()[0]
    if count == 0:
        rows = [
            ("Primary Healthcare Access", "Infrastructure", "Promotes awareness of nearby primary healthcare services.", "Rural and underserved communities"),
            ("Vaccination Awareness", "Prevention", "Provides general information about routine immunisation and preventive care.", "Families and children"),
            ("Telemedicine", "Digital Health", "Explains how remote consultations can improve access to healthcare.", "Remote and rural communities"),
            ("Healthy Lifestyle", "Wellness", "Encourages balanced nutrition, physical activity and regular health checks.", "General public")
        ]
        con.executemany(
            "INSERT INTO health_resources(title,category,description,audience) VALUES(?,?,?,?)",
            rows
        )
    con.commit()
    con.close()

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/resources")
def resources():
    category = request.args.get("category")
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    if category:
        rows = con.execute(
            "SELECT * FROM health_resources WHERE category=? ORDER BY id", (category,)
        ).fetchall()
    else:
        rows = con.execute("SELECT * FROM health_resources ORDER BY id").fetchall()
    con.close()
    return jsonify([dict(r) for r in rows])

@app.post("/api/feedback")
def feedback():
    data = request.get_json(silent=True) or {}
    message = str(data.get("message", "")).strip()
    if not message:
        return jsonify({"error": "Feedback message is required"}), 400
    # Demo only: do not store personally identifiable or medical information.
    return jsonify({"status": "received", "message": "Thank you for your feedback."}), 201

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
