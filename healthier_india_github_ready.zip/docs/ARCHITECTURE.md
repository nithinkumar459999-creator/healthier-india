# Architecture

## Overview

The prototype follows a small three-layer web architecture:

```text
Browser
   |
   v
HTML/CSS/JavaScript
   |
   v
Flask REST API
   |
   v
SQLite database
```

## Components

1. **Frontend** — responsive HTML/CSS and browser JavaScript.
2. **Application layer** — Flask routes expose resources and feedback endpoints.
3. **Data layer** — SQLite stores demonstration healthcare resources.
4. **Tests** — pytest validates core routes and API behaviour.

## Data flow

A user opens the homepage. JavaScript requests `/api/resources`. Flask reads the SQLite database and returns JSON. The browser renders resource cards.

## Safety and scope

The prototype is educational. It must not be used to diagnose, prescribe treatment, or replace professional medical care. A production system would require authentication, encryption, consent management, audit logging, clinical validation, accessibility testing, privacy controls and regulatory review.
