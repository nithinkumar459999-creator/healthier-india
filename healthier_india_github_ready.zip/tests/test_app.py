import os
import tempfile
import pytest
import app as application

@pytest.fixture()
def client(monkeypatch):
    fd, path = tempfile.mkstemp()
    os.close(fd)
    monkeypatch.setattr(application, "DB", path)
    application.init_db()
    application.app.config.update(TESTING=True)
    with application.app.test_client() as client:
        yield client
    os.unlink(path)

def test_homepage(client):
    response = client.get("/")
    assert response.status_code == 200
    assert b"Healthier India" in response.data

def test_resources(client):
    response = client.get("/api/resources")
    assert response.status_code == 200
    assert len(response.get_json()) >= 1

def test_category_filter(client):
    response = client.get("/api/resources?category=Prevention")
    assert response.status_code == 200
    assert all(x["category"] == "Prevention" for x in response.get_json())

def test_feedback_requires_message(client):
    response = client.post("/api/feedback", json={})
    assert response.status_code == 400

def test_feedback_success(client):
    response = client.post("/api/feedback", json={"message": "Good project"})
    assert response.status_code == 201
