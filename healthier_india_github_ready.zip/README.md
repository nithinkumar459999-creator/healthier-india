# Healthier India

**Theme:** Building a Healthier India: Progress, Innovation and Inclusive Healthcare Development

A GitHub-ready educational prototype showing how digital technology can support healthcare awareness and inclusion in India.

## Features

- Responsive web interface
- Healthcare resource catalogue
- Category filtering
- REST API
- SQLite sample database
- Feedback endpoint
- Automated pytest test cases
- Architecture and project documentation
- Open-source MIT license

## Tech stack

- Python 3.10+
- Flask
- SQLite
- HTML5
- CSS3
- JavaScript
- pytest

## Project structure

```text
healthier_india_project/
├── app.py
├── requirements.txt
├── README.md
├── LICENSE
├── .gitignore
├── templates/
│   └── index.html
├── static/
│   └── style.css
├── sample_data/
│   └── health_resources.csv
├── docs/
│   ├── ARCHITECTURE.md
│   └── PROJECT.md
└── tests/
    └── test_app.py
```

## Setup

### 1. Clone

```bash
git clone https://github.com/YOUR-USERNAME/healthier-india.git
cd healthier-india
```

### 2. Create a virtual environment

Windows:

```bash
python -m venv .venv
.venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run

```bash
python app.py
```

Open `http://127.0.0.1:5000` in your browser.

## Run tests

```bash
pytest -q
```

## API

### Get all resources

`GET /api/resources`

### Filter by category

`GET /api/resources?category=Prevention`

### Submit demo feedback

`POST /api/feedback`

Example JSON:

```json
{"message":"The interface is easy to use"}
```

## Sample data

See `sample_data/health_resources.csv`.

## Disclaimer

This project is an academic/educational prototype. It does not provide medical diagnosis, emergency advice, prescriptions, or personalised treatment. Only verified clinical/public-health sources should be used in a production deployment.

## License

MIT. See `LICENSE`.
